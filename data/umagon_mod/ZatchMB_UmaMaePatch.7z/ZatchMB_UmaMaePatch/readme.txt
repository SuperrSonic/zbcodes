~ Add files to Mamodo Battles to partly restore Umagon & Sunbeam and Maestro ~


1. Use a GC ISO tool that allows extracting and rebuilding.
2. Extract your ISO and look at the sys_files_to_replace folder.
3. fst.bin contains all the info of the new files, boot.bin updates the filesize of fst.bin.
4. The umO folder is supposed to be used to keep "partnerless Ponygon" working, it needs to be added even if it doesn't do anything yet.
5. seq0.fpk contains the files that make the character work in-game, the spells, hitboxes, camera postions, etc. are here.
6. After rebuilding the ISO file, run the game using the included code to force a specific character using the specified button combo.


Known issues:
Sunbeam's data in relation to spells was already present in-game, while Maestro's isn't,
this data is unique to the game and as such can't be brought over (at least not as far as I've been able to.) from YTB2.
So Maestro has no spells and several glitches because I use partnerless Ponygon's data for him.

Voice files, it's not known what file determines what triggers which sound, Sunbeam is mostly silent
and Maestro uses sounds from Bari, the menus, etc. Mamodo Battles does contain Maestro's sounds intact, but the
main executable doesn't list the file.

Note: the Japanese sound files do not restore Sunbeam's voice so I did not bother to include them.
