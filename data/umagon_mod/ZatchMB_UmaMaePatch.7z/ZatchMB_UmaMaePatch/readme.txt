UPDATE: Aug/17/2022
- Added an alt folder that contains files for just Umagon/Sunbeam, this prevents crashing when selecting
partnerless Ponygon due to the playable Maestro attempt. This is the recommended addition because it doesn't break anything.

NOTE1: seq0.fpk is the original file and is only included for easy reference.
NOTE2: GYKEB2.xml can be used with Dolphin's riivolution support to load the files without rebuilding the ISO.
NOTE3: seq_TEMPLATE.txt (after you edit the paths to match yours) can be used to repack seq0.fpk with gntool.
NOTE4: 0000_sun_JP.seg is YTB2's Sunbeam definitions file, it just crashes MB
but ideally this file might contain a clue to load the missing sounds.



~ Add files to Mamodo Battles to partly restore Umagon & Sunbeam and Maestro ~


1. Use a GC ISO tool that allows extracting and rebuilding.
2. Extract your ISO and look at the sys_files_to_replace folder.
3. fst.bin contains all the info of the new files, boot.bin updates the filesize of fst.bin.
4. The umO folder is supposed to be used to keep "partnerless Ponygon" working, it needs to be added even if it doesn't do anything yet.
5. seq0.fpk contains the files that make the character work in-game, the spells, hitboxes, camera postions, etc. are here.
6. After rebuilding the ISO file, run the game using the included code to force a specific character using the specified button combo.


Known issues:
Sunbeam's data in relation to spells was already present in-game, while Maestro's isn't,
this data is unique to the game and as such can't be brought over (at least not as far as I've been able to.) from YTB2.
So Maestro has no spells and several glitches because I use partnerless Ponygon's data for him.

Voice files, it's not known what file determines what triggers which sound, Sunbeam is mostly silent
and Maestro uses sounds from Bari, the menus, etc. Mamodo Battles does contain Maestro's sounds intact, but the
main executable doesn't list the file.

Note: the Japanese sound files do not restore Sunbeam's voice so I did not bother to include them.
