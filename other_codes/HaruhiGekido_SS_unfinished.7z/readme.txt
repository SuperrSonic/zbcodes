IPS_DOL_PATCHES:
main_ALWAYS_SHIFTJIS = Allows the game to display Japanese characters on NTSC-U/PAL region set.
(No need to apply this on Dolphin, it automatically changes things for Japanese games.)

main_NTSC_480p = Replaces 480i with 480p (doesn't read system settings)

main.dol contains a lot of text, I can't be 100% sure I translated it all but I think I did.
Even though menudata.bin is fully translated, some song names could use some tweaking.
Some item descriptions are also quite inaccurate, such as the "Vaulting Horse" item.

The info on the other text files might be wrong or messy, idk.

Score codes were tested on Dolphin only.


SuperrSonic:
https://www.youtube.com/channel/UCJD47CREoqENE_iLx1ZS73A
https://github.com/SuperrSonic
